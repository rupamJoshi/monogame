package com.mono;
public enum Id{
player(),
Enemy(),
ball(),
bricks();
}